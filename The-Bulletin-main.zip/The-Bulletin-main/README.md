<p align="center"><img src="app/src/main/ic_launcher-playstore.png" alt="StarWars" height="150px"></p>

# The Bulletin
An Android app built in Kotlin consuming [NEWS API](https://newsapi.org) to help people to know what's happening in the world currently. It also helps users to read news by category also user can save a news in the favourite section to read it later. Users can also show the details of the news.

### Purpose
The app is built to showcase the uses of latest Android Architecture components and best practices to build a 1-2 page app.

### Design pattern
- The app is built with Feature based architecture which uses Model-View-ViewModel as it's core architecture
- Each features contains 3 packages:
  - data - Holds the repository and data sources (remote/local)
  - domain - Holds the entity and model classes
  - presentation - Contains the View classes (Activity/Fragment/Adapter/ViewModel etc.)
  
  ## Tech Stack.
- [Kotlin](https://developer.android.com/kotlin) - Kotlin is a programming language that can run on JVM. Google has announced Kotlin as one of its officially supported programming languages in Android Studio; and the Android community is migrating at a pace from Java to Kotlin.
- Jetpack components:
    - [Android KTX](https://developer.android.com/kotlin/ktx.html) - Android KTX is a set of Kotlin extensions that are included with Android Jetpack and other Android libraries. KTX extensions provide concise, idiomatic Kotlin to Jetpack, Android platform, and other APIs.
    - [AndroidX](https://developer.android.com/jetpack/androidx) - Major improvement to the original Android [Support Library](https://developer.android.com/topic/libraries/support-library/index), which is no longer maintained.
    - [Lifecycle](https://developer.android.com/topic/libraries/architecture/lifecycle) - Lifecycle-aware components perform actions in response to a change in the lifecycle status of another component, such as activities and fragments. These components help you produce better-organized, and often lighter-weight code, that is easier to maintain.
    - [ViewModel](https://developer.android.com/topic/libraries/architecture/viewmodel) -The ViewModel class is designed to store and manage UI-related data in a lifecycle conscious way.
    - [LiveData](https://developer.android.com/topic/libraries/architecture/livedata) - LiveData is an observable data holder class. Unlike a regular observable, LiveData is lifecycle-aware, meaning it respects the lifecycle of other app components, such as activities, fragments, or services. This awareness ensures LiveData only updates app component observers that are in an active lifecycle state.
    - [Paging 3 library](https://developer.android.com/topic/libraries/architecture/paging/v3-overview) - The Paging library helps you load and display pages of data from a larger dataset from local storage or over network. This approach allows your app to use both network bandwidth and system resources more efficiently.
    - [Room database](https://developer.android.com/training/data-storage/room) - The Room persistence library provides an abstraction layer over SQLite to allow fluent database access while harnessing the full power of SQLite. -

- [Kotlin Coroutines](https://developer.android.com/kotlin/coroutines) - A concurrency design pattern that you can use on Android to simplify code that executes asynchronously.
- [Retrofit](https://square.github.io/retrofit) -  Retrofit is a REST client for Java/ Kotlin and Android by Square inc under Apache 2.0 license. Its a simple network library that is used for network transactions. By using this library we can seamlessly capture JSON response from web service/web API.
- [GSON](https://github.com/square/gson) - JSON Parser,used to parse requests on the data layer for Entities and understands Kotlin non-nullable and default parameters.
- [Kotlin Flow](https://developer.android.com/kotlin/flow) - In coroutines, a flow is a type that can emit multiple values sequentially, as opposed to suspend functions that return only a single value.
- [Dagger Hilt](https://developer.android.com/training/dependency-injection/hilt-android) - A dependency injection library for Android that reduces the boilerplate of doing manual dependency injection in your project.
- [Google AdMob](https://admob.google.com/home/) - AdMob is a mobile advertising subsidiary of Google

## Screenshots
### Splash screen
<img src="ss/splash.png" width="250"/>

### Home screen
<img src="ss/home_light.png" width="250"/> <img src="ss/home_dark.png" width="250"/>
#### Details
<img src="ss/details_light.png" width="250"/> <img src="ss/details_dark.png" width="250"/>

#### Favorites
<img src="ss/fav_light.png" width="250"/> <img src="ss/fav_dark.png" width="250"/>

### Settings
<img src="ss/settings_light.png" width="250"/> <img src="ss/settings_dark.png" width="250"/>

