package com.soumik.newsapp.core.utils

/**
created by Soumik on 3/22/2022
piyal.developer@gmail.com
copyright (c) 2022 Soumik Bhattacharjee. All rights reserved
 **/

enum class Status {
    SUCCESS,
    FAILED,
    LOADING
}